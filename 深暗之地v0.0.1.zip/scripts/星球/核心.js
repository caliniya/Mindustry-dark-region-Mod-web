
const powerProduction = 300; // 电量产生速率

const 核心 = Object.assign(extend(CoreBlock, "高温核心", {
    // 设置核心的基础统计信息
    setStats() {
        this.super$setStats();
        this.stats.add(Stat.basePowerGeneration, 60 * powerProduction, StatUnit.powerSecond);
    },
    // 设置核心的可放置和可破坏规则
    canBreak(tile) {
        return true;
        //Vars.state.teams.get(tile.team()).getCount(this) > 1;
    },
  
    // 设置核心的电力相关属性
    hasPower: true,
    consumesPower: false,
    outputsPower: true
}),
{
    buildType() {
        return extend(CoreBlock.CoreBuild, 核心, {
            getPowerProduction() {
                return powerProduction;
            }
        });
    }
    
});

exports.高温核心 = 核心;