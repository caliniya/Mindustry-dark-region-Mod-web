const 修复激光 = extend(ContinuousTurret, "修复激光", {
    repairRate: 50, // 每秒回复血量
    attackDamage: 5, // 每秒伤害
    powerUse: 10, // 每秒耗电量
updateTile: function(tile){
    Log.info("开始更新瓦片");
    this.super$updateTile(tile);
    Log.info("瓦片更新完成");

    // 检查是否有电力
    if (!this.cons.valid()) {
        Log.info("电力无效");
        return;
    }
        // 检查是否有电力
        if (!this.cons.valid()) return;

        // 检查周围是否有需要修复的友军建筑或单位
        let repairTargets = Units.nearby(this.team, tile.drawx(), tile.drawy(), this.range(), u => u.damaged() && !u.dead && (u instanceof Building || u.type.canRepair));
        if (repairTargets.length > 0) {
            // 优先修复友军
            this.target = Units.closest(this.team, tile.drawx(), tile.drawy(), this.range(), u => u.damaged() && !u.dead && (u instanceof Building || u.type.canRepair));
        } else {
            // 如果附近没有需要修复的友军，则攻击敌人
            this.target = Units.closestEnemy(this.team, tile.drawx(), tile.drawy(), this.range(), unit => unit.checkTarget(true, true));
        }

        if (this.target != null) {
            // 检查是否有足够的电力
            if (this.cons.getPower() >= this.powerUse * Time.delta()) {
                // 如果有目标，则射击
                if (this.target.team == this.team) {
                    // 如果目标是友方单位，则进行修复
                    this.repair(this.target);
                } else {
                    // 如果目标是敌方单位，则进行攻击
                    this.attack(this.target);
                }

                // 消耗电力
                this.consume();
            }
        }
    },

    repair: function(target){
        // 每秒回复血量
        target.heal(this.repairRate * Time.delta());
    },

    attack: function(target){
        // 每秒造成伤害
        target.damageContinuousPierce(this.attackDamage * Time.delta());
    }
});
exports.修复激光 = 修复激光;